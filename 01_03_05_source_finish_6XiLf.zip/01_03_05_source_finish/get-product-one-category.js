const request = require('request-promise');
const cheerio = require('cheerio');

const getProductInCategory = async () => {
    let maxPage = 100;

    for(i = 0; i < maxPage; i++) {
        let linkCategory = `http://demo-php-bookstore.zendvn.xyz/cong-nghe-thong-tin-3.html?page=${i+1}`;
        
        try {
            let html    = await request.get(linkCategory);
            let $       = await cheerio.load(html);

            if ($('.product-box').length > 0) {
                $('.product-box').each((i, elm)=> {
                    let name            = $(elm).find('.product-name').text();
                    let link            = $(elm).find('.product-link').attr('href');
                    let price_normal    = $(elm).find('.text-lowercase > del').text();
                    let price_sale      = $(elm).find('.text-lowercase').text().replace('đ '+ price_normal,'đ');
                    let image_link      = $(elm).find('.img-fluid').attr('src');
                    
                    let item            = {name, link, price_sale, price_normal, image_link};
                    console.log(item);
                })
            }else {
                break;
            }

        } catch (err) {
            console.error(err)
        }
    }
}
getProductInCategory();