const mongoose = require('mongoose');
const schema = new mongoose.Schema({ 
    name: String, 
    link: String
});
module.exports = mongoose.model('categories', schema);