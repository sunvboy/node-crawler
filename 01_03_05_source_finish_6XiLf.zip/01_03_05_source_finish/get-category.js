const request           = require('request-promise');
const cheerio           = require('cheerio');
const MainModel         = require('./schemas/category');
const mongoDBConnect    = require('./config/database');

mongoDBConnect();

const getCategory = async () => {
    let linkSiteGet = 'http://demo-php-bookstore.zendvn.xyz/index.html';
    
    try {
        let html    = await request.get(linkSiteGet);
        let $       = await cheerio.load(html);
        
        $('#main-menu > li:nth-child(4) > ul > li').each((i, elm)=> {
            let name = $(elm).children('a').text();
            let link = $(elm).children('a').attr('href');
            let item = {name, link};
            
            new MainModel(item).save().then(() => {console.log('Success!!!')});
        })
    } catch (err) {
        console.error(err)
    }
}
getCategory();