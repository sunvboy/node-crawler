const request       = require('request-promise');
const cheerio       = require('cheerio');
const fs            = require('fs');
const path          = require('path');
const CategoryModel = require('./schemas/category');
const ProductModel  = require('./schemas/product');
const mongoDBConnect= require('./config/database');

const folder_image  = './image/';

mongoDBConnect();

const downloadImg = function(uri, filename, callback){
    
    request.head(uri, function(err, res, body){
      console.log('content-type:', res.headers['content-type']);
      console.log('content-length:', res.headers['content-length']);
  
      request(uri).pipe(fs.createWriteStream(folder_image + filename)).on('close', callback);
    });
};

const getDescription = async (linkProduct) => {
    let html        = await request.get(linkProduct);
    let $           = await cheerio.load(html);
    let description = $('#top-home').html();
    return description;
}

const getProductInCategory = async (idCategory, nameCategory, link) => {
    let maxPage = 100;
    let linkMain = 'http://demo-php-bookstore.zendvn.xyz';

    for(i = 0; i < maxPage; i++) {
        let linkCategory = `http://demo-php-bookstore.zendvn.xyz${link}?page=${i+1}`;
        
        try {
            let html    = await request.get(linkCategory);
            let $       = await cheerio.load(html);
            let lengthBoxProduct = $('.product-box').length;
            if (lengthBoxProduct > 0) {

                for(k = 0; k < lengthBoxProduct; k++) {
                    let name            = $(`.product-box:eq(${k})`).find('.product-name').text();
                    let link            = $(`.product-box:eq(${k})`).find('.product-link').attr('href');
                    let price_normal    = $(`.product-box:eq(${k})`).find('.text-lowercase > del').text();
                    let price_sale      = $(`.product-box:eq(${k})`).find('.text-lowercase').text().replace('đ '+ price_normal,'đ');
                    let image_link      = $(`.product-box:eq(${k})`).find('.img-fluid').attr('src');
                    let category_name   = nameCategory;
                    let category_id     = idCategory;

                    let description     = await getDescription(linkMain + link);

                    let ext = path.extname(image_link);
                    let image_name = Math.random().toString(36).replace(/[^a-z]+/g, '').substr(0, 5) + ext;
                        

                    await downloadImg(linkMain + image_link, image_name, function(){
                        console.log('done');
                    });

                    let item = {name, link, price_sale, price_normal, image_name, category_name, category_id, description};
                    new ProductModel(item).save()
                }

            }else {
                break;
            }

        } catch (err) {
            console.error(err)
        }
    }
}

const getProductInAllCategory = async () => {
    let category = await CategoryModel.find();

    for(let j = 0; j < category.length; j++) {

        getProductInCategory(category[j].id, category[j].name, category[j].link);
        
    }
    
}

getProductInAllCategory()