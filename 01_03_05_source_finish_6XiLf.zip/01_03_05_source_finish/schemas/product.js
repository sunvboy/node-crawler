const mongoose = require('mongoose');
const schema = new mongoose.Schema({ 
    name: String, 
    link: String,
    price_sale: String,
    price_normal: String,
    image_name: String,
    category_name: String,
    category_id: String,
    description: String
});
module.exports = mongoose.model('product', schema);