const mongoose = require('mongoose');

const databaseConfig = {
    username: 'node-crawler',
    password: '123123123',
    database: 'node-crawler'
}

const mongoDBConnect = () => {
    // mongoDB
    mongoose.connect(`mongodb+srv://${databaseConfig.username}:${databaseConfig.password}@cluster0.esuco.mongodb.net/${databaseConfig.database}?retryWrites=false&w=majority`, {useNewUrlParser: true, useUnifiedTopology: true});
    const db = mongoose.connection;
    db.on('error', console.error.bind(console, 'connection error:'));
    db.once('open', function() {
        // we're connected!
        console.log('Database connected');
    });
}

module.exports = mongoDBConnect;